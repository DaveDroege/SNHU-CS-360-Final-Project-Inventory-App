package com.example.project2inventoryappdaviddroege;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private List<Item> items;
    private DatabaseHelper dbHelper;
    private OnItemChangeListener listener;

    // Interface for quantity change and deletion
    public interface OnItemChangeListener {
        void onItemChanged();
    }

    public InventoryAdapter(Context context, List<Item> items, OnItemChangeListener listener) {
        this.items = items;
        this.dbHelper = new DatabaseHelper(context);
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item item = items.get(position);
        holder.itemName.setText(item.getName());
        holder.quantityLabel.setText("Qty: " + item.getQuantity());

        // Increase quantity
        holder.increaseButton.setOnClickListener(v -> {
            item.setQuantity(item.getQuantity() + 1);
            dbHelper.updateItem(item.getId(), item.getQuantity());
            holder.quantityLabel.setText("Qty: " + item.getQuantity());
            listener.onItemChanged();
        });

        // Decrease quantity
        holder.decreaseButton.setOnClickListener(v -> {
            if (item.getQuantity() > 0) {
                item.setQuantity(item.getQuantity() - 1);
                dbHelper.updateItem(item.getId(), item.getQuantity());
                holder.quantityLabel.setText("Qty: " + item.getQuantity());
                listener.onItemChanged();
            }
        });

        // Delete item
        holder.deleteButton.setOnClickListener(v -> {
            dbHelper.deleteItem(item.getId());
            items.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, items.size());
            listener.onItemChanged();
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, quantityLabel;
        Button increaseButton, decreaseButton, deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            quantityLabel = itemView.findViewById(R.id.itemAmount);
            increaseButton = itemView.findViewById(R.id.increaseButton);
            decreaseButton = itemView.findViewById(R.id.decreaseButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
