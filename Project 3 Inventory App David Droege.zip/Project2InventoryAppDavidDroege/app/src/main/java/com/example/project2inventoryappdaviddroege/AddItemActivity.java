package com.example.project2inventoryappdaviddroege;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    private EditText itemNameInput, quantityInput;
    private Button submitItemButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize views and database
        itemNameInput = findViewById(R.id.itemNameInput);
        quantityInput = findViewById(R.id.quantityInput);
        submitItemButton = findViewById(R.id.submitItemButton);
        dbHelper = new DatabaseHelper(this);

        // Submit button click
        submitItemButton.setOnClickListener(v -> {
            String itemName = itemNameInput.getText().toString().trim();
            String quantityStr = quantityInput.getText().toString().trim();
            if (itemName.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(AddItemActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                int quantity = Integer.parseInt(quantityStr);
                if (dbHelper.addItem(itemName, quantity)) {
                    Toast.makeText(AddItemActivity.this, "Item added", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else {
                    Toast.makeText(AddItemActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
