package com.example.project2inventoryappdaviddroege;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements InventoryAdapter.OnItemChangeListener {
    private RecyclerView inventoryGrid;
    private FloatingActionButton addItemButton;
    private SearchView searchView;
    private DatabaseHelper dbHelper;
    private InventoryAdapter adapter;
    private List<Item> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views and database
        inventoryGrid = findViewById(R.id.inventoryGrid);
        addItemButton = findViewById(R.id.addItemButton);
        searchView = findViewById(R.id.searchView);
        dbHelper = new DatabaseHelper(this);
        items = new ArrayList<>();
        adapter = new InventoryAdapter(this, items, this);

        // Set up RecyclerView with GridLayout
        inventoryGrid.setLayoutManager(new GridLayoutManager(this, 2));
        inventoryGrid.setAdapter(adapter);

        // Load initial data
        loadItems();

        // Add item button
        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
            startActivityForResult(intent, 1);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterItems(newText);
                return true;
            }
        });
    }

    // Load all items from database
    private void loadItems() {
        items.clear();
        Cursor cursor = dbHelper.getAllItems();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
            items.add(new Item(id, name, quantity));
        }
        cursor.close();
        adapter.notifyDataSetChanged();
        checkLowInventory();
    }

    // Filter items based on search query
    private void filterItems(String query) {
        List<Item> filteredItems = new ArrayList<>();
        for (Item item : items) {
            if (item.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredItems.add(item);
            }
        }
        adapter = new InventoryAdapter(this, filteredItems, this);
        inventoryGrid.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            loadItems();
        }
    }

    @Override
    public void onItemChanged() {
        loadItems(); // Refresh grid and check low inventory
    }

    // Check for low inventory and navigate to SMS screen if needed
    private void checkLowInventory() {
        Cursor cursor = dbHelper.getLowInventoryItems(5); // Threshold: 5
        if (cursor.getCount() > 0) {
            Intent intent = new Intent(MainActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
        cursor.close();
    }
}
