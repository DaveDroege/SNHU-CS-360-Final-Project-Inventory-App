package com.example.project2inventoryappdaviddroege;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {
    private TextView permissionStatus, notificationStatus;
    private Button requestSmsPermission;
    private DatabaseHelper dbHelper;
    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // Initialize views and database
        permissionStatus = findViewById(R.id.permissionStatus);
        notificationStatus = findViewById(R.id.permissionStatus);
        requestSmsPermission = findViewById(R.id.requestSmsPermission);
        dbHelper = new DatabaseHelper(this);

        // Check initial permission status
        updatePermissionStatus();

        // Request permission button
        requestSmsPermission.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                sendLowInventoryNotifications();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            updatePermissionStatus();
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendLowInventoryNotifications();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Update permission status text
    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            permissionStatus.setText("SMS Notifications: Enabled");
            requestSmsPermission.setEnabled(false);
        } else {
            permissionStatus.setText("SMS Notifications: Not Enabled");
            requestSmsPermission.setEnabled(true);
        }
    }

    // Send SMS for low inventory items
    private void sendLowInventoryNotifications() {
        Cursor cursor = dbHelper.getLowInventoryItems(5); // Threshold: 5
        if (cursor.getCount() > 0) {
            StringBuilder message = new StringBuilder("Low inventory items:\n");
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                message.append(name).append(": ").append(quantity).append("\n");
            }
            notificationStatus.setText(message.toString());
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("+1234567890", null, message.toString(), null, null);
                Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            }
        } else {
            notificationStatus.setText("No low stock items");
        }
        cursor.close();
    }
}
